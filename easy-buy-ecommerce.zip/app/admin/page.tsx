import { Suspense } from "react"
import DashboardStats from "@/components/admin/dashboard-stats"
import RecentOrders from "@/components/admin/recent-orders"
import SalesChart from "@/components/admin/sales-chart"
import TopCategories from "@/components/admin/top-categories"
import QuickActions from "@/components/admin/quick-actions"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-white">Dashboard Overview</h1>
        <div className="text-slate-400">Welcome back, Admin</div>
      </div>

      {/* Stats Cards */}
      <Suspense fallback={<DashboardStatsSkeleton />}>
        <DashboardStats />
      </Suspense>

      {/* Charts and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Suspense fallback={<ChartSkeleton />}>
            <SalesChart />
          </Suspense>

          <Suspense fallback={<TableSkeleton />}>
            <RecentOrders />
          </Suspense>
        </div>

        <div className="space-y-6">
          <QuickActions />

          <Suspense fallback={<ChartSkeleton />}>
            <TopCategories />
          </Suspense>
        </div>
      </div>
    </div>
  )
}

function DashboardStatsSkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i} className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <Skeleton className="h-4 w-20 bg-slate-700 mb-2" />
            <Skeleton className="h-8 w-16 bg-slate-700 mb-2" />
            <Skeleton className="h-3 w-24 bg-slate-700" />
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

function ChartSkeleton() {
  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <Skeleton className="h-6 w-32 bg-slate-700" />
      </CardHeader>
      <CardContent>
        <Skeleton className="h-64 w-full bg-slate-700" />
      </CardContent>
    </Card>
  )
}

function TableSkeleton() {
  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <Skeleton className="h-6 w-32 bg-slate-700" />
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full bg-slate-700" />
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
