"use client"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import ProductCard, { ProductCardSkeleton } from "@/components/product-card"
import ProductFilters from "@/components/product-filters"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Grid, List } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock products data - replace with actual API call
const allProducts = [
  {
    id: "1",
    name: "Wireless Bluetooth Headphones",
    description: "Premium quality sound with noise cancellation",
    price: 129.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 15,
    category: "Electronics",
  },
  {
    id: "2",
    name: "Organic Cotton T-Shirt",
    description: "Comfortable and sustainable everyday wear",
    price: 29.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 50,
    category: "Clothing",
  },
  {
    id: "3",
    name: "Smart Home Security Camera",
    description: "HD video monitoring with mobile app",
    price: 89.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 8,
    category: "Electronics",
  },
  {
    id: "4",
    name: "Yoga Mat Premium",
    description: "Non-slip exercise mat for all fitness levels",
    price: 39.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 25,
    category: "Sports",
  },
  {
    id: "5",
    name: "Ceramic Coffee Mug Set",
    description: "Set of 4 handcrafted ceramic mugs",
    price: 24.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 12,
    category: "Home & Garden",
  },
  {
    id: "6",
    name: "LED Desk Lamp",
    description: "Adjustable brightness with USB charging",
    price: 49.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 20,
    category: "Electronics",
  },
  {
    id: "7",
    name: "Running Shoes",
    description: "Lightweight and comfortable for daily runs",
    price: 79.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 30,
    category: "Sports",
  },
  {
    id: "8",
    name: "Skincare Gift Set",
    description: "Complete skincare routine in a beautiful package",
    price: 59.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 18,
    category: "Beauty",
  },
  // Add more products for pagination demo
  ...Array.from({ length: 20 }, (_, i) => ({
    id: `${i + 9}`,
    name: `Product ${i + 9}`,
    description: `Description for product ${i + 9}`,
    price: Math.floor(Math.random() * 200) + 10,
    image: "/placeholder.svg?height=300&width=300",
    stock: Math.floor(Math.random() * 50) + 1,
    category: ["Electronics", "Clothing", "Sports", "Beauty", "Home & Garden"][Math.floor(Math.random() * 5)],
  })),
]

function ProductsContent() {
  const searchParams = useSearchParams()
  const [products, setProducts] = useState(allProducts)
  const [filteredProducts, setFilteredProducts] = useState(allProducts)
  const [searchQuery, setSearchQuery] = useState(searchParams.get("search") || "")
  const [sortBy, setSortBy] = useState("name")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [currentPage, setCurrentPage] = useState(1)
  const [filters, setFilters] = useState({
    category: searchParams.get("category") || "all",
    minPrice: "",
    maxPrice: "",
    inStock: false,
  })

  const productsPerPage = 12

  useEffect(() => {
    let filtered = [...allProducts]

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(
        (product) =>
          product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.description.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    // Apply category filter
    if (filters.category && filters.category !== "all") {
      filtered = filtered.filter((product) => product.category.toLowerCase() === filters.category.toLowerCase())
    }

    // Apply price filters
    if (filters.minPrice) {
      filtered = filtered.filter((product) => product.price >= Number.parseFloat(filters.minPrice))
    }
    if (filters.maxPrice) {
      filtered = filtered.filter((product) => product.price <= Number.parseFloat(filters.maxPrice))
    }

    // Apply stock filter
    if (filters.inStock) {
      filtered = filtered.filter((product) => product.stock > 0)
    }

    // Apply sorting
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.price - b.price
        case "price-high":
          return b.price - a.price
        case "name":
          return a.name.localeCompare(b.name)
        default:
          return 0
      }
    })

    setFilteredProducts(filtered)
    setCurrentPage(1)
  }, [searchQuery, filters, sortBy])

  const totalPages = Math.ceil(filteredProducts.length / productsPerPage)
  const startIndex = (currentPage - 1) * productsPerPage
  const paginatedProducts = filteredProducts.slice(startIndex, startIndex + productsPerPage)

  return (
    <div className="min-h-screen bg-slate-900">
      <Navbar />

      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Sidebar Filters */}
            <div className="lg:w-64 flex-shrink-0">
              <ProductFilters filters={filters} onFiltersChange={setFilters} />
            </div>

            {/* Main Content */}
            <div className="flex-1">
              {/* Search and Controls */}
              <div className="mb-6 space-y-4">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                    <Input
                      type="text"
                      placeholder="Search products..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 bg-slate-800 border-slate-600 text-white placeholder-slate-400 focus:border-emerald-500"
                    />
                  </div>

                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-full sm:w-48 bg-slate-800 border-slate-600 text-white">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-600">
                      <SelectItem value="name" className="text-white hover:bg-slate-700">
                        Name
                      </SelectItem>
                      <SelectItem value="price-low" className="text-white hover:bg-slate-700">
                        Price: Low to High
                      </SelectItem>
                      <SelectItem value="price-high" className="text-white hover:bg-slate-700">
                        Price: High to Low
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <p className="text-slate-400">
                    Showing {startIndex + 1}-{Math.min(startIndex + productsPerPage, filteredProducts.length)} of{" "}
                    {filteredProducts.length} products
                  </p>

                  <div className="flex items-center gap-2">
                    <Button
                      variant={viewMode === "grid" ? "default" : "outline"}
                      size="icon"
                      onClick={() => setViewMode("grid")}
                      className="bg-slate-800 border-slate-600 hover:bg-slate-700"
                    >
                      <Grid className="w-4 h-4" />
                    </Button>
                    <Button
                      variant={viewMode === "list" ? "default" : "outline"}
                      size="icon"
                      onClick={() => setViewMode("list")}
                      className="bg-slate-800 border-slate-600 hover:bg-slate-700"
                    >
                      <List className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Products Grid */}
              <div
                className={`grid gap-6 ${
                  viewMode === "grid" ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"
                }`}
              >
                {paginatedProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="mt-8 flex justify-center">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      className="bg-slate-800 border-slate-600 text-white hover:bg-slate-700"
                    >
                      Previous
                    </Button>

                    {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                      <Button
                        key={page}
                        variant={currentPage === page ? "default" : "outline"}
                        onClick={() => setCurrentPage(page)}
                        className={`${
                          currentPage === page
                            ? "bg-emerald-500 text-white"
                            : "bg-slate-800 border-slate-600 text-white hover:bg-slate-700"
                        }`}
                      >
                        {page}
                      </Button>
                    ))}

                    <Button
                      variant="outline"
                      onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                      className="bg-slate-800 border-slate-600 text-white hover:bg-slate-700"
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}

export default function ProductsPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-slate-900 py-8">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 12 }).map((_, i) => (
                <ProductCardSkeleton key={i} />
              ))}
            </div>
          </div>
        </div>
      }
    >
      <ProductsContent />
    </Suspense>
  )
}
