import Link from "next/link"
import { Smartphone, Shirt, Home, Dumbbell, BookOpen, Sparkles } from "lucide-react"

const categories = [
  {
    name: "Electronics",
    icon: Smartphone,
    description: "Latest gadgets and tech",
    count: "1,200+ items",
    href: "/products?category=electronics",
  },
  {
    name: "Clothing",
    icon: Shirt,
    description: "Fashion for every style",
    count: "800+ items",
    href: "/products?category=clothing",
  },
  {
    name: "Home & Garden",
    icon: Home,
    description: "Make your space beautiful",
    count: "600+ items",
    href: "/products?category=home-garden",
  },
  {
    name: "Sports",
    icon: Dumbbell,
    description: "Gear for active lifestyle",
    count: "400+ items",
    href: "/products?category=sports",
  },
  {
    name: "Books",
    icon: BookOpen,
    description: "Knowledge and entertainment",
    count: "300+ items",
    href: "/products?category=books",
  },
  {
    name: "Beauty",
    icon: Sparkles,
    description: "Self-care essentials",
    count: "250+ items",
    href: "/products?category=beauty",
  },
]

export default function CategoryBrowse() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {categories.map((category) => {
        const IconComponent = category.icon
        return (
          <Link
            key={category.name}
            href={category.href}
            className="group bg-slate-800 rounded-lg border border-slate-700 p-6 hover:border-emerald-500 transition-all duration-300 hover:shadow-lg hover:shadow-emerald-500/10"
          >
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-emerald-500/20 rounded-lg flex items-center justify-center group-hover:bg-emerald-500/30 transition-colors">
                <IconComponent className="w-6 h-6 text-emerald-400" />
              </div>

              <div className="flex-1">
                <h3 className="font-semibold text-white group-hover:text-emerald-400 transition-colors">
                  {category.name}
                </h3>
                <p className="text-sm text-slate-400 mt-1">{category.description}</p>
                <p className="text-xs text-emerald-400 mt-2">{category.count}</p>
              </div>
            </div>
          </Link>
        )
      })}
    </div>
  )
}
