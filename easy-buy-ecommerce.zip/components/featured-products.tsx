import ProductCard from "@/components/product-card"

// Mock data - replace with actual API call
const featuredProducts = [
  {
    id: "1",
    name: "Wireless Bluetooth Headphones",
    description: "Premium quality sound with noise cancellation",
    price: 129.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 15,
    category: "Electronics",
  },
  {
    id: "2",
    name: "Organic Cotton T-Shirt",
    description: "Comfortable and sustainable everyday wear",
    price: 29.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 50,
    category: "Clothing",
  },
  {
    id: "3",
    name: "Smart Home Security Camera",
    description: "HD video monitoring with mobile app",
    price: 89.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 8,
    category: "Electronics",
  },
  {
    id: "4",
    name: "Yoga Mat Premium",
    description: "Non-slip exercise mat for all fitness levels",
    price: 39.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 25,
    category: "Sports",
  },
  {
    id: "5",
    name: "Ceramic Coffee Mug Set",
    description: "Set of 4 handcrafted ceramic mugs",
    price: 24.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 12,
    category: "Home & Garden",
  },
  {
    id: "6",
    name: "LED Desk Lamp",
    description: "Adjustable brightness with USB charging",
    price: 49.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 20,
    category: "Electronics",
  },
  {
    id: "7",
    name: "Running Shoes",
    description: "Lightweight and comfortable for daily runs",
    price: 79.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 30,
    category: "Sports",
  },
  {
    id: "8",
    name: "Skincare Gift Set",
    description: "Complete skincare routine in a beautiful package",
    price: 59.99,
    image: "/placeholder.svg?height=300&width=300",
    stock: 18,
    category: "Beauty",
  },
]

export default function FeaturedProducts() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {featuredProducts.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  )
}
