import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, ShoppingBag } from "lucide-react"

export default function HeroSection() {
  return (
    <section className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-900 py-20 px-4 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.1),transparent_50%)]"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-6xl font-bold text-white leading-tight">
                Shop Smart,
                <span className="text-emerald-400 block">Live Better</span>
              </h1>
              <p className="text-xl text-slate-300 leading-relaxed max-w-lg">
                Discover amazing products at unbeatable prices. From electronics to fashion, we've got everything you
                need for modern living.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild size="lg" className="bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-3 text-lg">
                <Link href="/products" className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5" />
                  Start Shopping
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </Button>

              <Button
                asChild
                variant="outline"
                size="lg"
                className="border-emerald-500 text-emerald-400 hover:bg-emerald-500 hover:text-white px-8 py-3 text-lg"
              >
                <Link href="/categories">Browse Categories</Link>
              </Button>
            </div>

            <div className="flex items-center gap-8 pt-8">
              <div className="text-center">
                <div className="text-2xl font-bold text-emerald-400">10K+</div>
                <div className="text-slate-400">Happy Customers</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-emerald-400">5K+</div>
                <div className="text-slate-400">Products</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-emerald-400">24/7</div>
                <div className="text-slate-400">Support</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="relative z-10 bg-slate-800 rounded-2xl p-8 shadow-2xl border border-slate-700">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-semibold text-white">Featured Deal</h3>
                  <span className="bg-emerald-500 text-white px-3 py-1 rounded-full text-sm font-medium">50% OFF</span>
                </div>

                <div className="aspect-square bg-slate-700 rounded-lg flex items-center justify-center">
                  <div className="w-32 h-32 bg-emerald-500/20 rounded-lg flex items-center justify-center">
                    <ShoppingBag className="w-16 h-16 text-emerald-400" />
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="text-lg font-medium text-white">Premium Wireless Headphones</h4>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-bold text-emerald-400">$99</span>
                    <span className="text-slate-400 line-through">$199</span>
                  </div>
                </div>

                <Button className="w-full bg-emerald-500 hover:bg-emerald-600 text-white">Grab This Deal</Button>
              </div>
            </div>

            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-emerald-500/20 rounded-full blur-xl"></div>
            <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-emerald-400/10 rounded-full blur-xl"></div>
          </div>
        </div>
      </div>
    </section>
  )
}
