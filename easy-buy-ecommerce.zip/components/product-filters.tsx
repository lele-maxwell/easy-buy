"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"

interface Filters {
  category: string
  minPrice: string
  maxPrice: string
  inStock: boolean
}

interface ProductFiltersProps {
  filters: Filters
  onFiltersChange: (filters: Filters) => void
}

const categories = ["Electronics", "Clothing", "Home & Garden", "Sports", "Books", "Beauty"]

export default function ProductFilters({ filters, onFiltersChange }: ProductFiltersProps) {
  const [isOpen, setIsOpen] = useState(false)

  const updateFilter = (key: keyof Filters, value: string | boolean) => {
    onFiltersChange({
      ...filters,
      [key]: value,
    })
  }

  const clearFilters = () => {
    onFiltersChange({
      category: "all",
      minPrice: "",
      maxPrice: "",
      inStock: false,
    })
  }

  const hasActiveFilters =
    (filters.category && filters.category !== "all") || filters.minPrice || filters.maxPrice || filters.inStock

  return (
    <>
      {/* Mobile Filter Toggle */}
      <div className="lg:hidden mb-4">
        <Button
          onClick={() => setIsOpen(!isOpen)}
          variant="outline"
          className="w-full bg-slate-800 border-slate-600 text-white hover:bg-slate-700"
        >
          Filters {hasActiveFilters && `(${Object.values(filters).filter(Boolean).length})`}
        </Button>
      </div>

      {/* Filter Panel */}
      <div
        className={`${
          isOpen ? "block" : "hidden"
        } lg:block bg-slate-800 rounded-lg border border-slate-700 p-6 space-y-6`}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-white">Filters</h3>
          {hasActiveFilters && (
            <Button
              onClick={clearFilters}
              variant="ghost"
              size="sm"
              className="text-emerald-400 hover:text-emerald-300 hover:bg-slate-700"
            >
              Clear All
            </Button>
          )}
        </div>

        <Separator className="bg-slate-700" />

        {/* Category Filter */}
        <div className="space-y-3">
          <Label className="text-white font-medium">Category</Label>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="all-categories"
                checked={filters.category === "all" || !filters.category}
                onCheckedChange={(checked) => {
                  updateFilter("category", checked ? "all" : "all")
                }}
                className="border-slate-600 data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500"
              />
              <Label htmlFor="all-categories" className="text-slate-300 hover:text-white cursor-pointer">
                All Categories
              </Label>
            </div>
            {categories.map((category) => (
              <div key={category} className="flex items-center space-x-2">
                <Checkbox
                  id={category}
                  checked={filters.category === category.toLowerCase()}
                  onCheckedChange={(checked) => {
                    updateFilter("category", checked ? category.toLowerCase() : "all")
                  }}
                  className="border-slate-600 data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500"
                />
                <Label htmlFor={category} className="text-slate-300 hover:text-white cursor-pointer">
                  {category}
                </Label>
              </div>
            ))}
          </div>
        </div>

        <Separator className="bg-slate-700" />

        {/* Price Range Filter */}
        <div className="space-y-3">
          <Label className="text-white font-medium">Price Range</Label>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="minPrice" className="text-slate-400 text-sm">
                Min
              </Label>
              <Input
                id="minPrice"
                type="number"
                placeholder="$0"
                value={filters.minPrice}
                onChange={(e) => updateFilter("minPrice", e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-emerald-500"
              />
            </div>
            <div>
              <Label htmlFor="maxPrice" className="text-slate-400 text-sm">
                Max
              </Label>
              <Input
                id="maxPrice"
                type="number"
                placeholder="$999"
                value={filters.maxPrice}
                onChange={(e) => updateFilter("maxPrice", e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-emerald-500"
              />
            </div>
          </div>
        </div>

        <Separator className="bg-slate-700" />

        {/* Stock Filter */}
        <div className="space-y-3">
          <Label className="text-white font-medium">Availability</Label>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="inStock"
              checked={filters.inStock}
              onCheckedChange={(checked) => updateFilter("inStock", !!checked)}
              className="border-slate-600 data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500"
            />
            <Label htmlFor="inStock" className="text-slate-300 hover:text-white cursor-pointer">
              In Stock Only
            </Label>
          </div>
        </div>

        {/* Mobile Close Button */}
        <div className="lg:hidden pt-4">
          <Button onClick={() => setIsOpen(false)} className="w-full bg-emerald-500 hover:bg-emerald-600 text-white">
            Apply Filters
          </Button>
        </div>
      </div>
    </>
  )
}
